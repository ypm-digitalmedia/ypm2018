# owl
OWL Carousel for Drupal 8
+ Field formatter: See video: https://www.youtube.com/watch?v=PzBMJqkNHQ0
+ Views integrated see video: https://www.youtube.com/watch?v=kKps02rc3pE

Subscribe us on Facebook
https://www.facebook.com/TabvnGroup

##Website: https://tabvn.com
<a href="https://www.upwork.com/o/companies/_~012a10c4ff792ca829/" rel="nofollow"><img src="https://d1a6a9r46cnyll.cloudfront.net/39cf672e47f6fa58d02a7a678441c04252385203/687474703a2f2f636c6f75642e746162766e2e636f6d2f313434333037373131302e706e67" alt="hire Tabvn.com"></a>

###License: Free for your personal project. 
